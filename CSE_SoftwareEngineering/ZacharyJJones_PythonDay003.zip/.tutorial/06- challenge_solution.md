# Solution (No Peeking!)

<details> <summary> 👀 Answer</summary>

```python
food = input("Name a type of food: ")
plant = input("Name a plant: ")
cookingType = input("What is a way to cook something? ")
burntFood = input("How do you describe burnt food? ")
householdItem = input("Name something in your house: ")

print()
print("Tonight's dinner:")

print("For dinner you should make", cookingType, food, "with", burntFood, plant, "on a plate of", householdItem)
```

</details>