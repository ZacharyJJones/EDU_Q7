print("Lets make an Ultimate Wacky Recipe!!!")
print("I'll ask you for a bunch of your favorite things, and combine them in a metaphysical bowl! Then I'll serve you up a word salad that you are GUARANTEED to enjoy.")

print()
print("OK, tell me some favorites!")

food = input("Name a food: ")
plant = input("Name a type of plant: ")
cooking = input("Name a method of cooking: ")
household = input("Name a household item: ")

burn = input("Now, give me a word to describe burned food: ")

# -----------

print()
print()
print()
print()
print("And now here is the recipe!!")
print()
print("Behold the...", cooking, food, "with", burn, plant, "on a bed of", household)