name = input("What is your name??: ")
food = input("What is your favorite food?: ")
music = input("What music do you like listening to?: ")
living = input("Where do you live????: ")

print("You (allegedly) like eating " + food + ", listening to " + music + ", and you live in " + living + ".")

print("Well, " + name + ". It looks like you lead a very interesting life. Nice going!")